Java_project
Advanced Task Manager (ATM) - Java Edition

Overview

This is a command-line-based To-Do List Application developed in Java. It is designed to provide robust task management features, including task categorization, prioritization, and persistent data storage, making it suitable for academic and personal use.

Features

Core CRUD Operations: Add, View, and Delete tasks.

Module 1: Task Prioritization: Allows tasks to be marked as High, Medium, or Low.

Module 2: Status Tracking: Allows tasks to be marked as PENDING, IN PROGRESS, or COMPLETE.

Module 3: Task Filtering: Users can filter the display list by Priority or Status.

Persistence: Tasks are automatically saved to and loaded from tasks.txt.

Technologies/Tools Used

Primary Language: Java (Core Java/SE)

Data Structure: java.util.ArrayList for in-memory storage.

File I/O: java.io.FileReader, FileWriter, and BufferedReader/BufferedWriter.

Build/Testing: Standard Java Compiler (javac). (Future plan: JUnit for testing.)

Installation & Running

Prerequisites: Ensure Java Development Kit (JDK) 8 or higher is installed.

Compile: Navigate to the project directory and compile the source file:
javac ToDoListApp.java

Run: Execute the compiled class:

java ToDoListApp


Instructions for Testing (Manual)

Run the application.

Select option 1 (Add Task). Input tasks with different priorities (e.g., Task 1 [High], Task 2 [Low]).

Select option 2 (View Tasks). Verify the list includes all tasks.

Select option 5 (Filter Tasks). Filter by status or priority and confirm the list updates correctly.

Select option 4 (Exit). The application should confirm saving tasks to tasks.txt.

Restart the application. Confirm that all previously added tasks are loaded correctly from tasks.txt.