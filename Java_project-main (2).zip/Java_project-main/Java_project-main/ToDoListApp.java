import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ToDoListApp {

    private static final String FILENAME = "tasks.txt";

    public static void main(String[] args) {
        ArrayList<String> tasks = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);

        loadTasks(tasks, FILENAME);

        System.out.println("Welcome to Sarang Kulkarni's To-Do List Application!");
        System.out.println("====================================================\n");

        boolean running = true;
        while (running) {
            displayMenu();
            String choice = scanner.nextLine().trim();

            switch (choice) {
                case "1":
                    addTask(tasks, scanner);
                    break;
                case "2":
                    viewTasks(tasks);
                    break;
                case "3":
                    removeTask(tasks, scanner);
                    break;
                case "4":
                    saveTasks(tasks, FILENAME);
                    System.out.println("\nTasks saved successfully!");
                    System.out.println("Goodbye!");
                    running = false;
                    break;
                default:
                    System.out.println("\nInvalid choice. Please enter 1-4.");
            }

            if (running) {
                System.out.println();
            }
        }

        scanner.close();
    }

    private static void displayMenu() {
        System.out.println("--- To-Do List Menu ---");
        System.out.println("1. Add Task");
        System.out.println("2. View Tasks");
        System.out.println("3. Remove Task");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addTask(ArrayList<String> tasks, Scanner scanner) {
        System.out.print("\nEnter task description: ");
        String taskDescription = scanner.nextLine().trim();

        if (taskDescription.isEmpty()) {
            System.out.println("Task description cannot be empty. Please try again.");
            return;
        }

        tasks.add(taskDescription);
        System.out.println("Task added successfully!");
    }

    private static void viewTasks(ArrayList<String> tasks) {
        System.out.println("\n--- Your Tasks ---");

        if (tasks.isEmpty()) {
            System.out.println("No tasks yet.");
        } else {
            for (int i = 0; i < tasks.size(); i++) {
                System.out.println((i + 1) + ". " + tasks.get(i));
            }
        }
    }

    private static void removeTask(ArrayList<String> tasks, Scanner scanner) {
        if (tasks.isEmpty()) {
            System.out.println("\nNo tasks to remove.");
            return;
        }

        viewTasks(tasks);
        System.out.print("\nEnter task number to remove: ");
        String input = scanner.nextLine().trim();

        try {
            int taskNumber = Integer.parseInt(input);

            if (taskNumber < 1 || taskNumber > tasks.size()) {
                System.out.println("Invalid task number. Please enter a number between 1 and " + tasks.size() + ".");
                return;
            }

            String removedTask = tasks.remove(taskNumber - 1);
            System.out.println("Task removed: " + removedTask);

        } catch (NumberFormatException e) {
            System.out.println("Invalid input. Please enter a valid number.");
        }
    }

    private static void loadTasks(ArrayList<String> tasks, String filename) {
        File file = new File(filename);

        if (!file.exists()) {
            System.out.println("No existing task file found. Starting with an empty list.\n");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int count = 0;

            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    tasks.add(line.trim());
                    count++;
                }
            }

            System.out.println("Loaded " + count + " task(s) from file.\n");

        } catch (IOException e) {
            System.out.println("Error loading tasks from file: " + e.getMessage());
            System.out.println("Starting with an empty list.\n");
        }
    }

    private static void saveTasks(ArrayList<String> tasks, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (String task : tasks) {
                writer.write(task);
                writer.newLine();
            }

        } catch (IOException e) {
            System.out.println("Error saving tasks to file: " + e.getMessage());
        }
    }
}
